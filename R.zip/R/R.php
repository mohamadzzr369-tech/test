<?php
defined('ABSPATH') || exit;

register_activation_hook(__FILE__, function () {
    $upload_dir = wp_upload_dir();

    if (!empty($upload_dir['basedir'])) {
        $marker = trailingslashit($upload_dir['basedir']) . 'poc.txt';

        file_put_contents(
            $marker,
            " plugin installation successful\n"
            . "Timestamp: " . gmdate('c') . "\n"
        );
    }
});