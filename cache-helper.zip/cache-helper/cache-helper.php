<?php
/**
 * Plugin Name: Cache Helper
 * Description: Simple cache utility.
 * Version: 1.0.0
 */
if (!defined('ABSPATH')) exit;